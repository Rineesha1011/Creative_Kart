import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  constructor() { }

  myimage:string = "D:/WISE-WebProject/Angular/CreativeKart/src/assets/images/bgpic.jpg"

  ngOnInit(): void {
  }

}
