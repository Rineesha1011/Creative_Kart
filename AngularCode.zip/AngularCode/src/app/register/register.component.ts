import { Component, OnInit } from '@angular/core';
import { CustService } from '../cust.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  customer : any;
  constructor(private router: Router, private service : CustService) {
    this.customer = {customerId : '', firstName : '', lastName : '', email : '', street : '', city : '', 
    state :'', phoneNo : '', password : ''
  }
   }

  ngOnInit(): void {
  }

  register(): void {
    this.service.registerCust(this.customer).subscribe((result: any) => { console.log(result); 
      localStorage.setItem('customer', this.customer.firstName);
    this.router.navigate(['home']);
  } );
    console.log(this.customer);
  }

}
