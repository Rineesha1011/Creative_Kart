import { Component, OnInit } from '@angular/core';
import { CustService } from '../cust.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: any;
  constructor(private router: Router, private custService: CustService) {
    this.user = {loginId: '', password: ''};
  }

  ngOnInit(): void {
  }

  loginSubmit(loginForm: any): void {
    this.custService.loginCust(this.user).subscribe((result: any) => { console.log(result); 
    if (result != null) {
      this.custService.setUserLoggedIn();
      localStorage.setItem('customer', result.firstName);
      this.router.navigate(['home']);
    } else {
      alert('Invalid Credentials..');
    }
    console.log(loginForm);
  } )
  }
  
}
