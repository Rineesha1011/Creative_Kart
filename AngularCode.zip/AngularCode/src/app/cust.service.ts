import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { retry } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustService {
  private isUserLogged: boolean;
  cartItems = [];
  productToBeAdded: Subject<any>;

  constructor(private httpClient: HttpClient) {
    this.isUserLogged = false;
    this.productToBeAdded = new Subject();
   }

   setUserLoggedIn(): void { // login success
    this.isUserLogged = true;
   }
   setUserLoggedOut(): void { // logout success
    this.isUserLogged = false;
   }
   getUserLogged(): any { // call this in AuthGuard
     return this.isUserLogged;
   }
  
   registerCust(customer: any) {
     console.log('Inside service');
     console.log(customer);
    return this.httpClient.post('Creative_Kart/webapi/myresource/registerCust/',customer);
   }
   loginCust(user: any) {
    return this.httpClient.get('Creative_Kart/webapi/myresource/getCustByUserPass/' + user.loginId + '/' + user.password);
   }
   addToCart(product: any) {
    this.productToBeAdded.next(product);
    this.cartItems.push(product);
    // localStorage.setItem('cartItems', JSON.stringify(this.cartItems));
  }

  getForCart() {
    return this.productToBeAdded.asObservable();
  }

  postFile(ImageForm: any, fileToUpload: File) {
    // const endpoint='RESTAPI/webapi/myresource/';
    const formData: FormData = new FormData();
    formData.append('Image', fileToUpload, fileToUpload.name);
    formData.append('productName', ImageForm.productName);
    formData.append('description', ImageForm.description);
    formData.append('price', ImageForm.price);

    return this.httpClient.post('RestAPI/webapi/myresource/uploadImage', formData);
  }
  getEmpByEmail(email: string): any {
    // alert('Inside service:' + email);
    return this.httpClient.get('RestAPI/webapi/myresource/getEmpByEmail/' + email).toPromise();
  }
   //getImage(): Observable<File> {
    //console.log('Inside Service...');
   // return this.httpClient.get('Creative_Kart/webapi/myresource/downloadImage', { responseType: 'blob' });
   //}
   getProducts() {
   return this.httpClient.get('Creative_Kart/webapi/myresource/getProducts').pipe(retry(10));
   }
}
